EDIT Update 1.2.1: It looks like the mod is back online!
No longer hidden and available for download on Nexus as of February 2021.

SO IMPORTANT UPDATE!!! The Stardew Valley 1.5 update had some mod-breaking changes.

Here is a message from the creator of NPC Adventures, PurrplingCat (12/31/2020):

"The last day of NPC Adventures and Quest Framework. 
Tomorrow NA disapears from Nexusmods and QF will be marked as deprecated and not recommended for make new quest mods based on.
Thank you all for your best work. You did really good things on NPC Adventures and on Quest Framework, but every fun one day must end. 
And the day is today. My mods died due to breaking changes in SDV 1.5 and it's too much changes I am not able to fix it. 
Sorry. It's time to say STOP and leave."

NPC Adventures is currently discontinued as of January 2021. I will still provide Lucikiel's NPC Aventures compatibility just in case.
I did find that Lucikiel can still be recruited if you play around with the debug mode in the config.json for the old NPC Adventures folder.
However, I think this will be the last update for NPC Adventures unless someone is able to help fix it.

Thanks for supporting Lucikiel and NPC Adventures. It was fun to be a part of the crew while it lasted ;)
I have updated Lucikiel with a minor Clint expansion (new event) to honor the memory NPC Adventures.

EDIT Update 1.2.1: It looks like the mod is back online!

"It's been a wild adventure."

-Arknir27